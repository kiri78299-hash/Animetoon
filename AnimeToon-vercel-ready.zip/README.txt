AnimeToon — Vercel deployment

Entry point: index.html
Supporting files: script.js, style.css

This is a static site and requires no build command or framework configuration.
